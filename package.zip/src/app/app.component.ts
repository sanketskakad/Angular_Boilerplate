import { Component } from '@angular/core';
import { ElementRef, ViewChildren, AfterViewChecked, QueryList, Renderer2 } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  height1 =0 ;
  title = 'app';
  collection = [
    {
      q: `The best and most beautiful things in the world cannot be seen or even touched `,
      a: `Helen Keller`
    },
    {
      q: `The best and most beautiful `,
      a: `Helen Keller`
    },
    {
      q: `with the heart.`,
      a: `Helen Keller`
    },
    {
      q: `The best and most beautiful things in the world cannot be seen or even touched - they must be felt with the heart.`,
      a: `Helen Keller`
    }
  ];



  ngAfterViewChecked(): void {
    //this.viewHeight = this.elementView;
    //console.log(this.elementView._results[0].nativeElement.offsetHeight)
    
    this.elementView.forEach(
      (a) => {
        if (a.nativeElement.offsetHeight > this.height1) {
          this.height1 = a.nativeElement.offsetHeight;
        }
      }
    )

   // console.log(this.height1)

    this.elementView.forEach((a) => {
      console.log(a.nativeElement)
      this.re.setStyle(a.nativeElement , "height", this.height1+'px')
    })

   // this.re.setStyle(this.elementView,"height" , 300)
   // console.log(this.elementView)
  }


  @ViewChildren('mainScreen') elementView: QueryList<ElementRef>;
  viewHeight: number;

  constructor(private re: Renderer2) {
  }


  clickMe() {
    //  this.viewHeight = this.elementView.nativeElement.offsetHeight;
    console.log(this.viewHeight)
  }
}

